.. :changelog:

History
-------

1.0.0 (2021-03-11)
++++++++++++++++++

* First release on PyPI.
